package db;

import model.Tasks;

import java.util.ArrayList;
import java.util.Objects;

public class DBManager {
    private static ArrayList<Tasks> tasksArrayList = new ArrayList<>();
    public static Long id = 2L;

    static {
        tasksArrayList.add(new Tasks(1L, "Создать Веб приложение на JAVA EE", "Нужно будет создать собственное приложение на Java ЕЕ для себя. Для начала я установлю\n" +
                "себе на комп Composer. Затем тупо загружу Java EE и запущу.", "23.10.2021", true));
    }

    public ArrayList<Tasks> getAllTasks(){
        return tasksArrayList;
    }

    public void addTask(Tasks task){
        task.setId(id);
        tasksArrayList.add(task);
        id++;
    }

    public Tasks getTask(Long id){
        for (Tasks task : tasksArrayList){
            if (Objects.equals(task.getId(), id)){
                return task;
            }
        }
        return null;
    }

}