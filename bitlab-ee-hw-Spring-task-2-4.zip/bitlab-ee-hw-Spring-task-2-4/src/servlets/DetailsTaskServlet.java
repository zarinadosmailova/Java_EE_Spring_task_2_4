package servlets;

public class DetailsTaskServlet {
}
